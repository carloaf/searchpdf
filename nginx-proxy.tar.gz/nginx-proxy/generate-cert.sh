#!/usr/bin/env bash
#
# Gera um certificado autoassinado para o listener HTTPS (443) do nginx-proxy.
#
# Uso:
#   cd nginx-proxy
#   ./generate-cert.sh [domínio] [dias_de_validade]
#
# Exemplos:
#   ./generate-cert.sh
#   ./generate-cert.sh sipbo.11dsup.eb.mil.br 3650
#
# O certificado é usado APENAS no backend (10.166.72.36:443). O TLS que o
# usuário vê no navegador é fornecido pelo proxy externo (10.166.72.33) com o
# certificado *.11dsup.eb.mil.br, portanto não há alerta de certificado no
# navegador do usuário final.

set -euo pipefail

DOMAIN="${1:-sipbo.11dsup.eb.mil.br}"
DAYS="${2:-3650}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CERTS_DIR="${SCRIPT_DIR}/certs"

mkdir -p "${CERTS_DIR}"

openssl req -x509 -nodes -newkey rsa:2048 \
    -days "${DAYS}" \
    -keyout "${CERTS_DIR}/sipbo.key" \
    -out "${CERTS_DIR}/sipbo.crt" \
    -subj "/C=BR/ST=DF/L=Brasilia/O=EB/OU=11DSUP/CN=${DOMAIN}" \
    -addext "subjectAltName=DNS:${DOMAIN},IP:10.166.72.36"

chmod 600 "${CERTS_DIR}/sipbo.key"
chmod 644 "${CERTS_DIR}/sipbo.crt"

echo "Certificado gerado: ${CERTS_DIR}/sipbo.crt"
echo "Chave privada gerada: ${CERTS_DIR}/sipbo.key"
echo
echo "Agora inicie/reinicie o proxy:"
echo "  cd ${SCRIPT_DIR} && docker compose up -d"
echo "  docker exec nginx_proxy nginx -t"
